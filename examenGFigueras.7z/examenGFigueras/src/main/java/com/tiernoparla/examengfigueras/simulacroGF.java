package com.tiernoparla.examengfigueras;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import javax.swing.text.DefaultStyledDocument.ElementSpec;

public class simulacroGF {
    public static Scanner sc = new Scanner(System.in);
    public static Integer size = sc.nextInt();
    public static Integer[] arrayJuego = new Integer[size];
    public static Boolean turno = true;
    public static int randomNumber;
    public static int cuenta;

    public static void turnoJugador() {
        System.out.println("TURNO JUGADOR");
        System.out.println("posiciones disponibles: ");
        for (int i = 0; i < arrayJuego.length; i++) {
            if (arrayJuego[i] == null) {
                System.out.print(i + " ");
            }
        }
        System.out.println(Arrays.toString(arrayJuego));
        System.out.println("que posicion quieres modificar??");
        int numero = sc.nextInt();
        if (arrayJuego[numero] == null) {
            arrayJuego[numero] = 1;
            turnoMaquina();
        } else {
            System.out.println("no puedes añadir esa posicion");
            turnoJugador();
        }
        turno = false;
    }

    public static Integer nAleatorio(int numero) {
        randomNumber = (int) Math.round(Math.random() * numero);
        return randomNumber;
    }

    public static void turnoMaquina() {
        System.out.println("TURNO MAQUINA");
        integer num = randomNumber(arrayJuego.length);
        if (arrayJuego[num] == null) {
            arrayJuego[num] = 0;
        } else {
            turnoMaquina();
        }
    }

    public static void main(String[] args) {
        while (turno = true) {
            turnoJugador();
        }
        turnoMaquina();
    }
}
